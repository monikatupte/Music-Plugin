<div>

    <?php #echo do_shortcode('[music genre="43"]'); ?>
    <h2><?php _e('WP Music plugin','wpmusic'); ?></h2>
    <p>WP Music is the easiest way to play background music on your WordPress website.</p>
    <form action="options.php" method="post">
        <?php settings_fields('wpmusic_options'); ?>
        <?php do_settings_sections('wpmusic'); ?>
        <input name="Submit" type="submit" value="<?php esc_attr_e('Save Changes'); ?>" />
    </form>
</div>