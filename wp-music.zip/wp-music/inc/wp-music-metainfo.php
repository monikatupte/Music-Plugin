<div class="wpm_box">
    <p class="meta-options wpm_field">
        <label for="wpm_composer">Composer Name</label>
        <input id="wpm_composer" type="text" name="wpm_composer" value="<?php echo esc_attr( get_post_meta( get_the_ID(), 'wpm_composer', true ) ); ?>">
    </p>
    <p class="meta-options wpm_field">
        <label for="wpm_publisher">Publisher</label>
        <input id="wpm_publisher" type="text" name="wpm_publisher" value="<?php echo esc_attr( get_post_meta( get_the_ID(), 'wpm_publisher', true ) ); ?>">
    </p>
    <p class="meta-options wpm_field">
        <label for="wpm_yearr">Year of recording</label>
        <input id="wpm_yearr" type="date" name="wpm_yearr" value="<?php echo esc_attr( get_post_meta( get_the_ID(), 'wpm_yearr', true ) ); ?>">
    </p>
    <p class="meta-options wpm_field">
        <label for="wpm_contributers">Additional Contributors</label>
        <input id="wpm_contributers" type="text" name="wpm_contributers" value="<?php echo esc_attr( get_post_meta( get_the_ID(), 'wpm_contributers', true ) ); ?>">
    </p>
    <p class="meta-options wpm_field">
        <label for="wpm_url">URL</label>
        <input id="wpm_url" type="text" name="wpm_url" value="<?php echo esc_attr( get_post_meta( get_the_ID(), 'wpm_url', true ) ); ?>">
    </p>
    <p class="meta-options wpm_field">
        <label for="wpm_price">Price</label>
        <input id="wpm_price" type="text" name="wpm_price" value="<?php echo esc_attr( get_post_meta( get_the_ID(), 'wpm_price', true ) ); ?>">
    </p>
</div>