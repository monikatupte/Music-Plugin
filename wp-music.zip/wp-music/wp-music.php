<?php

/*
Plugin Name: Wp Music
Plugin URI: #
Description: Plugin is related to music, registers a post type, texonomy, tags and all.
Version: 1.0
Author: Admin
Author URI: #
License: #
Text Domain: wpmusic
*/

function wp_music_styles() {
    wp_enqueue_style( 'music-style',  plugin_dir_url( __FILE__ ) . 'assets/css/style.css' );
}
add_action( 'admin_enqueue_scripts', 'wp_music_styles' );

// add the admin options page
add_action('admin_menu', 'wpmusic_admin_add_page');
function wpmusic_admin_add_page() {
    add_menu_page( __( 'Wp Music', 'wpmusic' ), 'Wp Music', 'manage_options', 'wp-music', 'wpmusic_options_page', 'dashicons-admin-media', 6);
    add_submenu_page('wp-music', 'Settings', 'Settings', 'manage_options', 'music-settings', 'wpmusic_settings_page');
}

/**
 * Activate the plugin.
 */
function wpmusic_activate() {

    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );

    // Trigger our function that registers the custom post type plugin.
    wpmusic_register_post_type(); 

    //* Create the wp_music_metadata table
    $table_name = $wpdb->prefix . 'music_metadata';
    $sql = "CREATE TABLE $table_name ( meta_id INTEGER NOT NULL AUTO_INCREMENT, post_id TEXT NOT NULL, team_city TEXT NOT NULL, wpm_composer TEXT NOT NULL, wpm_publisher TEXT NOT NULL, wpm_yearr TEXT NOT NULL, wpm_contributers TEXT NOT NULL, wpm_url TEXT NOT NULL, wpm_price TEXT NOT NULL, PRIMARY KEY (meta_id)) $charset_collate;";
    dbDelta( $sql );

    // Clear the permalinks after the post type has been registered.
    flush_rewrite_rules(); 
}
register_activation_hook( __FILE__, 'wpmusic_activate' );

/**
 * Deactivation hook.
 */
function wpmusic_deactivate() {
    // Unregister the post type, so the rules are no longer in memory.
    unregister_post_type( 'music' );
    // Clear the permalinks to remove our post type's rules from the database.
    flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'wpmusic_deactivate' );

// display the admin options page
function wpmusic_options_page() {
	echo "Welcome to Music"; exit;
}

// display the admin settings page
function wpmusic_settings_page() {
	include_once('inc/wp-music-settings.php');
	//echo 2; exit;
}

// add the admin settings and such
add_action('admin_init', 'wpmusic_admin_init');
function wpmusic_admin_init() {
    register_setting('wpmusic_options', 'wpmusic_options', 'wpmusic_options_validate');
    add_settings_section('wpmusic-settings', 'Settings', 'wpmusic_section_text', 'wpmusic');
    add_settings_field('music_displayed_per_page', 'Number of musics displayed per page :', 'post_per_page', 'wpmusic', 'wpmusic-settings');
    add_settings_field('music_currency_fields', 'Currency', 'wpmusic_settings', 'wpmusic', 'wpmusic-settings');
}

function wpmusic_section_text() {
    _e('','wpmusic');
}

//Show Notices
add_action('admin_notices', 'wpmusic_admin_notice');
function wpmusic_admin_notice() {
    global $pagenow;
    //echo '<pre>'; print_r($_GET);
    if ($_GET['page'] === 'music-settings' && $_GET['settings-updated'] == 'true') {
        echo '<div id="setting-error-settings_updated" class="notice notice-success settings-error is-dismissible"> <p><strong>Settings saved.</strong></p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>';
    }
}

function post_per_page() {
    $options = get_option('wpmusic_options');
    $content = '';

    $content .= '<input type="text" id="music_displayed_per_page" name="wpmusic_options[post_per_page]" value="'.$options['post_per_page'].'">';
    echo $content;
}

function wpmusic_settings() {
    $options = get_option('wpmusic_options');
    $content = '';

    if($options['currency'] === "USD"){
        $selected = "selected='selected'";
    } else {
        $selected = "selected=''";
    }

    $content .= '<select id="music_currency_fields" name="wpmusic_options[currency]">
                    <option>'.$options['currency'].'</option>
                    <option value="United States Dollars">United States Dollars</option>
                    <option value="Euro">Euro</option>
                    <option value="United Kingdom Pounds">United Kingdom Pounds</option>
                    <option value="Algeria Dinars">Algeria Dinars</option>
                    <option value="Argentina Pesos">Argentina Pesos</option>
                    <option value="Australia Dollars">Australia Dollars</option>
                    <option value="Austria Schillings">Austria Schillings</option>
                    <option value="Bahamas Dollars">Bahamas Dollars</option>
                    <option value="Barbados Dollars">Barbados Dollars</option>
                    <option value="Belgium Francs">Belgium Francs</option>
                    <option value="Bermuda Dollars">Bermuda Dollars</option>
                    <option value="Brazil Real">Brazil Real</option>
                    <option value="Bulgaria Lev">Bulgaria Lev</option>
                    <option value="CAD">Canada Dollars</option>
                    <option value="CLP">Chile Pesos</option>
                    <option value="CNY">China Yuan Renmimbi</option>
                    <option value="CYP">Cyprus Pounds</option>
                    <option value="CSK">Czech Republic Koruna</option>
                    <option value="DKK">Denmark Kroner</option>
                    <option value="NLG">Dutch Guilders</option>
                    <option value="XCD">Eastern Caribbean Dollars</option>
                    <option value="EGP">Egypt Pounds</option>
                    <option value="FJD">Fiji Dollars</option>
                    <option value="FIM">Finland Markka</option>
                    <option value="FRF">France Francs</option>
                    <option value="DEM">Germany Deutsche Marks</option>
                    <option value="XAU">Gold Ounces</option>
                    <option value="GRD">Greece Drachmas</option>
                    <option value="HKD">Hong Kong Dollars</option>
                    <option value="HUF">Hungary Forint</option>
                    <option value="ISK">Iceland Krona</option>
                    <option value="INR">India Rupees</option>
                    <option value="IDR">Indonesia Rupiah</option>
                    <option value="IEP">Ireland Punt</option>
                    <option value="ILS">Israel New Shekels</option>
                    <option value="ITL">Italy Lira</option>
                    <option value="JMD">Jamaica Dollars</option>
                    <option value="JPY">Japan Yen</option>
                    <option value="JOD">Jordan Dinar</option>
                    <option value="KRW">Korea (South) Won</option>
                    <option value="LBP">Lebanon Pounds</option>
                    <option value="LUF">Luxembourg Francs</option>
                    <option value="MYR">Malaysia Ringgit</option>
                    <option value="MXP">Mexico Pesos</option>
                    <option value="NLG">Netherlands Guilders</option>
                    <option value="NZD">New Zealand Dollars</option>
                    <option value="NOK">Norway Kroner</option>
                    <option value="PKR">Pakistan Rupees</option>
                    <option value="XPD">Palladium Ounces</option>
                    <option value="PHP">Philippines Pesos</option>
                    <option value="XPT">Platinum Ounces</option>
                    <option value="PLZ">Poland Zloty</option>
                    <option value="PTE">Portugal Escudo</option>
                    <option value="ROL">Romania Leu</option>
                    <option value="RUR">Russia Rubles</option>
                    <option value="SAR">Saudi Arabia Riyal</option>
                    <option value="XAG">Silver Ounces</option>
                    <option value="SGD">Singapore Dollars</option>
                    <option value="SKK">Slovakia Koruna</option>
                    <option value="ZAR">South Africa Rand</option>
                    <option value="KRW">South Korea Won</option>
                    <option value="ESP">Spain Pesetas</option>
                    <option value="XDR">Special Drawing Right (IMF)</option>
                    <option value="SDD">Sudan Dinar</option>
                    <option value="SEK">Sweden Krona</option>
                    <option value="CHF">Switzerland Francs</option>
                    <option value="TWD">Taiwan Dollars</option>
                    <option value="THB">Thailand Baht</option>
                    <option value="TTD">Trinidad and Tobago Dollars</option>
                    <option value="TRL">Turkey Lira</option>
                    <option value="VEB">Venezuela Bolivar</option>
                    <option value="ZMK">Zambia Kwacha</option>
                    <option value="EUR">Euro</option>
                    <option value="XCD">Eastern Caribbean Dollars</option>
                    <option value="XDR">Special Drawing Right (IMF)</option>
                    <option value="XAG">Silver Ounces</option>
                    <option value="XAU">Gold Ounces</option>
                    <option value="XPD">Palladium Ounces</option>
                    <option value="XPT">Platinum Ounces</option>
                </select>';
    echo $content;
}

// validate our options (doing nothing here...)
function wpmusic_options_validate($input) {
    $options = get_option('wpmusic_options');
    $options['post_per_page'] = trim($input['post_per_page']);
    $options['currency'] = trim($input['currency']);
    return $options;
}

// Create a Custom post type music
add_action( 'init', 'wpmusic_register_post_type' );
function wpmusic_register_post_type() {
    // music
    $labels = array( 
        'name' => __( 'Music' , 'wpmusic' ),
        'singular_name' => __( 'Music' , 'wpmusic' ),
        'add_new' => __( 'New Music' , 'wpmusic' ),
        'add_new_item' => __( 'Add New Music' , 'wpmusic' ),
        'edit_item' => __( 'Edit Music' , 'wpmusic' ),
        'new_item' => __( 'New Music' , 'wpmusic' ),
        'view_item' => __( 'View Music' , 'wpmusic' ),
        'search_items' => __( 'Search Musics' , 'wpmusic' ),
        'not_found' =>  __( 'No Musics Found' , 'wpmusic' ),
        'not_found_in_trash' => __( 'No Musics found in Trash' , 'wpmusic' ),
    );

    register_post_type('music', array(
		'labels' => $labels,
		'has_archive' => true,
        'public' => true,
        'hierarchical' => false,
        'supports' => array(
            'title', 
            'editor', 
            'excerpt', 
            'custom-fields', 
            'thumbnail',
            'page-attributes'
        ),
        'rewrite'   => array( 'slug' => 'music' ),
        'show_in_rest' => true
	));

}

// Create a Custom post texonomy for music post
add_action( 'init', 'wpmusic_register_taxonomy' );
function wpmusic_register_taxonomy() {
    $labels = array(
        'name' => __( 'Genre' , 'wpmusic' ),
        'singular_name' => __( 'Genre', 'wpmusic' ),
        'search_items' => __( 'Search Genres' , 'wpmusic' ),
        'all_items' => __( 'All Genres' , 'wpmusic' ),
        'edit_item' => __( 'Edit Genre' , 'wpmusic' ),
        'update_item' => __( 'Update Genres' , 'wpmusic' ),
        'add_new_item' => __( 'Add New Genre' , 'wpmusic' ),
        'new_item_name' => __( 'New Genre Name' , 'wpmusic' ),
        'menu_name' => __( 'Genre' , 'wpmusic' ),
    );
     
    $args = array(
        'labels' => $labels,
        'hierarchical' => true,
        'sort' => true,
        'args' => array( 'orderby' => 'term_order' ),
        'rewrite' => array( 'slug' => 'genres' ),
        'show_admin_column' => true,
        'show_in_rest' => true
 
    );
    register_taxonomy( 'music-genre', array( 'music' ), $args);
}

// Create a Custom post tags for music post
add_action( 'init', 'sigma_mt_tags_games', 5 );
function sigma_mt_tags_games(){
    register_taxonomy('music-tag','music',
        array(
            'hierarchical'  => true,
            'labels' => array(
                'add_new_item' => __('Add Music Tag', 'sigmaigaming'),
                'new_item_name' => __('Music Tag', 'sigmaigaming')
            ),
            'label'         => __('Music Tag', 'sigmaigaming'),
            'singular_name' => __('Music Tag', 'sigmaigaming'),
            'rewrite'       => [
                'slug' => 'tags',
                'with_front' => false
            ],
            'show_tagcloud' => true,
            'show_admin_column' => true,
            'query_var'     => true
        )
    );
}

/**
 * Register meta boxes.
 */
add_action( 'add_meta_boxes', 'wpmusic_register_meta_boxes' );
function wpmusic_register_meta_boxes() {
    add_meta_box( 'wpmusic-meta-info', __( 'Music Information', 'wpmusic' ), 'wpmusic_display_callback', 'music' );
}

function wpmusic_display_callback( $post ) {
    include_once('inc/wp-music-metainfo.php');
}

//Save meta box content.
function wpmusic_save_meta_box( $post_id ) {
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( $parent_id = wp_is_post_revision( $post_id ) ) {
        $post_id = $parent_id;
    }
    $fields = [
        'wpm_composer',
        'wpm_publisher',
        'wpm_yearr',
        'wpm_contributers',
        'wpm_url',
        'wpm_price',
    ];
    foreach ( $fields as $field ) {
        if ( array_key_exists( $field, $_POST ) ) {
            update_post_meta( $post_id, $field, sanitize_text_field( $_POST[$field] ) );
        }
     }
}
add_action( 'save_post', 'wpmusic_save_meta_box' );

//Shortcode to get music_info.
add_shortcode( 'music', 'music_info' );
function music_info($atts) {
    $content = '';
    $year = isset($atts['year']) ? $atts['year'] : 'date';
    $term_id = isset($atts['genre']) ? $atts['genre'] : '';
    if(!empty($term_id)) {
        $post_args = array(
            'posts_per_page' => $count,
            'post_type' => 'music',
            'orderby' => $year,
            'order'   => 'ASC',
            'tax_query' => array(
                array(
                  'taxonomy' => 'music-genre',
                  'field' => 'term_id',
                  'terms' => $term_id,
                )
            )
        );
    } else {
        $post_args = array(
            'posts_per_page' => $count,
            'post_type' => 'music',
            'orderby' => $year,
            'order'   => 'ASC',
        );
    }
    $posts = get_posts($post_args);
    //echo '<pre>'; print_r($atts['position']);
    if(!empty($posts)) {
        $content .= '<div class="music-information">';
            foreach($posts as $v => $post) {
                $wpm_composer = get_post_meta( $post->ID, 'wpm_composer', true );
                $wpm_publisher = get_post_meta( $post->ID, 'wpm_publisher', true );
                $wpm_contributers = get_post_meta( $post->ID, 'wpm_contributers', true );
                $wpm_yearr = get_post_meta( $post->ID, 'wpm_yearr', true );
                $wpm_url = get_post_meta( $post->ID, 'wpm_url', true );
                $wpm_price = get_post_meta( $post->ID, 'wpm_price', true );
                $content .= '<div class="">
                                <h3>Post Title : '.$post->post_title.'</h3>
                                <table>
                                    <tr>
                                        <td>Composer Name : '.$wpm_composer.'</td>
                                    </tr>
                                    <tr>
                                        <td>Publisher : '.$wpm_publisher.'</td>
                                    </tr>
                                        <td>Year Of recording  : '.$wpm_yearr.'</td>
                                    </tr>
                                    <tr>
                                        <td>Additional Contributer : '.$wpm_contributers.'</td>
                                    </tr>
                                    <tr>
                                        <td>URL : '.$wpm_url.'</td>
                                    </tr>
                                    <tr>
                                        <td>Price : '.$wpm_price.'</td>
                                    </tr>
                                </table>
                            </div>

                            <style>
                            table {
                              font-family: arial, sans-serif;
                              border-collapse: collapse;
                              width: 100%;
                            }

                            td, th {
                              border: 1px solid #dddddd;
                              text-align: left;
                              padding: 8px;
                            }

                            tr:nth-child(even) {
                              background-color: #dddddd;
                            }
                            </style>
';
            }
        $content .= '</div>';
    }
    return $content;
}